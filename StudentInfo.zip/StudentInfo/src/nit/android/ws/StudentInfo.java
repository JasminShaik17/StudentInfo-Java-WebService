package nit.android.ws;

public interface StudentInfo {
	
	String insertStudentInfo(Student s);

}
