package nit.android.ws;

public class StudentInfoImpl implements 
StudentInfo{

	@Override
	public String insertStudentInfo(Student s) {
		System.out.println(s.getName()+"\n"+
						s.getGender()+"\n"+
						s.getEmail()+"\n"+
						s.getMobileno());
		return "success";
	}
	
	

}
